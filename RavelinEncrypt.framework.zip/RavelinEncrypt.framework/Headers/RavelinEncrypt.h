//
//  RavelinEncrypt.h
//  RavelinEncrypt
//
//  Copyright © 2018 Ravelin. All rights reserved.

#import <UIKit/UIKit.h>

//! Project version number for RavelinEncrypt.
FOUNDATION_EXPORT double RavelinEncryptVersionNumber;

//! Project version string for RavelinEncrypt.
FOUNDATION_EXPORT const unsigned char RavelinEncryptVersionString[];

// Public headers - NOTE: Remember to add any of the headers below to the buildphases > Public or you will get build errors
#import "RVNEncryption.h"
